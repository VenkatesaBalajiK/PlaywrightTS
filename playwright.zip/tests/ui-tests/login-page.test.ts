import { test } from "@fixtures/custom-fixtures";
import { Config } from "@utils/config-reader/config";

test(`login test - ${Config.currentEnvironment}`, { tag: "@Validlogin" }, async ({ loginPageSteps, moduleNavigator }) => {
  await loginPageSteps.navigateToUrl(Config.appUrl);
  await loginPageSteps.performLogin("Venkat", "123");
  await moduleNavigator.navigateToRequiredModule("Data Source");
  // console.log(Config.database);
  // console.log(Config.sqlChat);
});

