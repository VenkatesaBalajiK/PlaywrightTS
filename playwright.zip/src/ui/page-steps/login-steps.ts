import { test, Page } from "@fixtures/custom-fixtures";
import { LoginPageLocators } from "@ui/pages/login-page-locators";


export class LoginPageSteps {
  private page: Page;
  private loginLocators: LoginPageLocators;

  constructor(page: Page) {
    this.page = page;
    this.loginLocators = new LoginPageLocators(page);
  }

  async navigateToUrl(url: string) {
    await test.step("Navigate to app url", async () => {
      await this.page.goto(url);
    });
  }

  async performLogin(userId: string, password: string) {
    await test.step("Logging into application", async () => {
      await this.loginLocators.getUserIdTextBox().fill(userId);
      await this.loginLocators.getPasswordTextBox().fill(password);
      await this.loginLocators.getLoginButton().click();
    });
  }
}
