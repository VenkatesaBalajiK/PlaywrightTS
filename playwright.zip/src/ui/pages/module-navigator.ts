import { test } from "@fixtures/custom-fixtures";
import { LocatorFileConstants } from "@constants/locators-files-constants";
import { YamlReader } from "@utils/file-utils/yaml-reader";
import { PageElementLocator } from "@utils/playwright-utils/page-element-locator";
import { Page } from "@fixtures/custom-fixtures";
import { moduleMapping, ModuleName } from "types/module-mapping";

export class ModuleNavigator {
  private page: Page;
  private locatorUtils: PageElementLocator;
  private locatorMap: Record<string, any>;

  constructor(page: Page) {
    this.page = page;
    this.locatorUtils = new PageElementLocator(this.page);

    // Load YAML file **only once** in constructor
    const yamlReader = new YamlReader(LocatorFileConstants.SIDEBAR_COMPONENTS_LOCATORS);
    this.locatorMap = yamlReader.read();
  }

  /**
   * Dynamically retrieves a module locator.
   */
  private getModuleLocator(moduleKey: string) {
    return this.locatorUtils.getLocator(this.locatorMap, "sidebar", moduleKey);
  }

  /**
   * Navigate to a required module, clicking "More" if necessary.
   */
  public async navigateToRequiredModule(moduleName: ModuleName) {
    await test.step(`Navigate to ${moduleName} module`, async () => {
      const yamlKey = moduleMapping[moduleName.toLowerCase() as Lowercase<ModuleName>];
      if (!yamlKey) {
        throw new Error(`Module "${moduleName}" not found in sidebar locators.`);
      }

      const moduleLocator = this.getModuleLocator(yamlKey);
      if (!moduleLocator) {
        throw new Error(`Module "${moduleName}" does not have a valid locator.`);
      }

      // Click "More" only if module is not directly visible
      const moreLocator = this.getModuleLocator("more");
      if (moreLocator && !(await moduleLocator.isVisible())) {
        await moreLocator.click();
      }

      await moduleLocator.click();
    });
  }
}
