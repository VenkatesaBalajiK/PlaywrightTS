import { LocatorFileConstants } from "@constants/locators-files-constants";
import { YamlReader } from "@utils/file-utils/yaml-reader";
import { PageElementLocator } from "@utils/playwright-utils/page-element-locator";
import { Page } from "@fixtures/custom-fixtures";

export class LoginPageLocators {
  private page: Page;
  private locatorUtils: PageElementLocator;
  private locatorMap: Record<string, any>;

  constructor(page: Page) {
    this.page = page;
    this.locatorUtils = new PageElementLocator(this.page);

    // Load YAML file **only once** in constructor
    const yamlReader = new YamlReader(LocatorFileConstants.LOGIN_PAGE_LOCATORS);
    this.locatorMap = yamlReader.read();
  }

  public getUserIdTextBox() {
    return  this.locatorUtils.getLocator(this.locatorMap,"LoginLocators", "user_id_input");
  }

  public getPasswordTextBox() {
    return  this.locatorUtils.getLocator(this.locatorMap,"LoginLocators", "password_input");
  }

  public getLoginButton() {
    return  this.locatorUtils.getLocator(this.locatorMap,"LoginLocators", "login_button");
  }
}
