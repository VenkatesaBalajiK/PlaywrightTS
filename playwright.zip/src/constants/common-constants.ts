export class CommonConstants {
    static readonly ENV_DETAILS = "./src/configs/env-config.yaml";
    static readonly DOWNLOAD_PATH = "./downloads/";
    static readonly TEST_FOLDER_PATH = "../../tests/";
    static readonly TEST_SUITE_FILE_FORMAT = ".test.ts";
    static readonly PARALLEL_MODE = "parallel";
    static readonly SERIAL_MODE = "serial";
}