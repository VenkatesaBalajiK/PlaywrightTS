export class LocatorFileConstants {
  static readonly LOGIN_PAGE_LOCATORS = "./src/ui/locators/login-locators.yaml";
  static readonly SIDEBAR_COMPONENTS_LOCATORS = './src/ui/locators/module-locators.yaml'
  
}
