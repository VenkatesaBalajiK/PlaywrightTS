import { Page, Locator } from '@playwright/test';
import { LocatorType } from 'types/locators-type';

export class PageElementLocator {
    private page: Page;
    private locators: Map<string, (value: string, roleName?: string) => Locator>;

    constructor(page: Page) {
        this.page = page;

        // Define a Map for efficient locator retrieval
        this.locators = new Map<string, (value: string, roleName?: string) => Locator>([
            ['text', this.getElementByText.bind(this)],
            ['label', this.getElementByLabel.bind(this)],
            ['placeholder', this.getElementByPlaceholder.bind(this)],
            ['alttext', this.getElementByAltText.bind(this)],
            ['title', this.getElementByTitle.bind(this)],
            ['testid', this.getElementByTestId.bind(this)],
            ['cssorxpath', this.getElementByCssOrXpathLocator.bind(this)],
            ['classname', this.getElementByClassName.bind(this)],
            ['id', this.getElementById.bind(this)],
            ['role', this.getElementByRoleAndName.bind(this)],
        ]);
    }

    /**
     * Finds an element based on the specified type and value(s).
     * @param type - The type of locator.
     * @param value - The primary value associated with the locator type.
     * @param roleName - Name of the role (if applicable).
     * @returns Locator of the matching element.
     * @throws Error if an unsupported type is provided.
     */
    public getElement(type: LocatorType, value: string, roleName?: string): Locator {
        const locatorFunction = this.locators.get(type.toLowerCase());

        if (!locatorFunction) {
            throw new Error(`Unsupported locator type: "${type}". Supported types: ${Array.from(this.locators.keys())}`);
        }

        // Calls the function directly, letting 'role' handle its own logic
        return locatorFunction(value, roleName);
    }

    /**
    * Helper method to safely fetch locators from YAML and handle missing keys.
    */
    public getLocator(locatorMap: Record<string, any>, section: string, key: string) {
        const locator = locatorMap?.[section]?.[key];

        if (!locator) {
            throw new Error(`Locator "${section}.${key}" is missing in YAML file.`);
        }

        if (locator.type === 'role') {
            return this.getElement(locator.type, locator.role, locator.value,);
        } else {
            return this.getElement(locator.type, locator.value);
        }
    }

    // Private methods for retrieving locators
    private getElementByText(text: string): Locator {
        return this.page.getByText(text);
    }

    private getElementByLabel(label: string): Locator {
        return this.page.getByLabel(label);
    }

    private getElementByPlaceholder(placeholder: string): Locator {
        return this.page.getByPlaceholder(placeholder);
    }

    private getElementByAltText(altText: string): Locator {
        return this.page.getByAltText(altText);
    }

    private getElementByTitle(title: string): Locator {
        return this.page.getByTitle(title);
    }

    private getElementByTestId(testId: string): Locator {
        return this.page.getByTestId(testId);
    }

    private getElementByCssOrXpathLocator(selector: string): Locator {
        return this.page.locator(selector);
    }

    /**
     * Handles role-based locators without requiring extra conditions in `getElement()`
     */
    private getElementByRoleAndName(role: string, name?: string): Locator {
        if (!name) {
            throw new Error(`Missing 'name' parameter for role-based locator.`);
        }
        return this.page.getByRole(role as any, { name });
    }

    private getElementByClassName(className: string): Locator {
        return this.page.locator(`.${className}`);
    }

    private getElementById(id: string): Locator {
        return this.page.locator(`#${id}`);
    }
}
