import { YamlReader } from '@utils/file-utils/yaml-reader'
import { CommonConstants } from '@constants/common-constants'

export class Config {
  private static envConfig = new YamlReader(CommonConstants.ENV_DETAILS).read();

  // Get environment from CLI args or default to 'qa'
  private static currentEnv: string = process.env.TEST_ENV || 'qa';

  private static get envData() {
    if (!this.envConfig || !this.envConfig.environments) {
      console.error("Error: YAML file is not loaded correctly.");
      return {};
    }

    const envData = this.envConfig.environments[this.currentEnv];

    if (!envData) {
      console.error(`Error: Environment '${this.currentEnv}' is missing in the YAML file.`);
      return {};
    }

    return envData;
  }

  // App URL
  static get appUrl(): string {
    return this.envData.app_url;
  }

  // Database Config
  static get database() {
    return {
      host: this.envData.database?.host,
      port: this.envData.database?.port,
      username: this.envData.database?.username,
      password: process.env.DB_PASSWORD || this.envData.database?.password // Use env var for security
    };
  }

  // SQL Chatbot API Config
  static get sqlChat() {
    return {
      baseUrl: this.envData.sql_chat?.base_url,
      port: this.envData.sql_chat?.port,
      endpoints: {
        request: this.envData.sql_chat?.endpoints?.request,
        response: this.envData.sql_chat?.endpoints?.response,
        processStatus: this.envData.sql_chat?.endpoints?.process_status,
      },
    };
  }

  // Get current environment name
  static get currentEnvironment(): string {
    return this.currentEnv;
  }
}
