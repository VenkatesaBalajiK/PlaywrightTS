export type ModuleName = 
  | "Chatbot"
  | "Compare And Contrast"
  | "Analytics"
  | "Uploads"
  | "Client Materiality Map"
  | "User Profile"
  | "Settings"
  | "Help"
  | "More"
  | "Security"
  | "Fund Master"
  | "Fund Group"
  | "ESG Internal Category"
  | "Data Source"
  | "Metric Data Dictionary"
  | "Default Metric Mapping"
  | "Classification"
  | "ESG Data"
  | "Data Age Report"
  | "Position"
  | "Roles"
  | "Users";

/**
 * Mapping of user-friendly module names to their YAML keys.
 */
export const moduleMapping: Record<Lowercase<ModuleName>, string> = {
  "chatbot": "chatbot",
  "compare and contrast": "compare_and_constrast",
  "analytics": "analytics",
  "uploads": "uploads",
  "client materiality map": "client_materiality_map",
  "user profile": "user_profile",
  "settings": "settings",
  "help": "help",
  "more": "more",
  "security": "security",
  "fund master": "fund_master",
  "fund group": "fund_group",
  "esg internal category": "esg_internal_category",
  "data source": "data_source",
  "metric data dictionary": "metric_data_dictionary",
  "default metric mapping": "default_metric_mapping",
  "classification": "classification",
  "esg data": "esg_data",
  "data age report": "data_age_report",
  "position": "position",
  "roles": "roles",
  "users": "users"
};
