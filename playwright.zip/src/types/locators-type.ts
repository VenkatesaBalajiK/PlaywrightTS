/**
 * Type representing supported locator strategies.
 */
export type LocatorType =
    | 'text'
    | 'label'
    | 'placeholder'
    | 'altText'
    | 'title'
    | 'testId'
    | 'cssOrXpath'
    | 'role'
    | 'className'
    | 'id';
