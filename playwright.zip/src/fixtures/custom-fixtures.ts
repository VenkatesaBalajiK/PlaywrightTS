import { test as base } from "@playwright/test";
import { LoginPageSteps } from "@ui/page-steps/login-steps";
import {ModuleNavigator } from "@ui/pages/module-navigator";

interface PageFixtures {
  loginPageSteps: LoginPageSteps;
  moduleNavigator: ModuleNavigator;
}

export const test = base.extend<PageFixtures>({
  loginPageSteps: async ({ page }, use) => {
    await use(new LoginPageSteps(page));
  },

  moduleNavigator: async ({ page }, use) => {
    await use(new ModuleNavigator(page));
  }
});

export { expect, Page } from "@playwright/test";
